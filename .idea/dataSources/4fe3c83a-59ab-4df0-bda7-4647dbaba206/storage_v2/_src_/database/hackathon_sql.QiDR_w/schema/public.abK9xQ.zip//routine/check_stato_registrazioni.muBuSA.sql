create function check_stato_registrazioni() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verifica se la data_inizio è meno di 2 giorni dalla data corrente
    IF NEW.data_inizio < CURRENT_DATE + INTERVAL '2 days' THEN
        -- Imposta stato_registrazioni a false
        NEW.stato_registrazioni := false;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function check_stato_registrazioni() owner to postgres;

