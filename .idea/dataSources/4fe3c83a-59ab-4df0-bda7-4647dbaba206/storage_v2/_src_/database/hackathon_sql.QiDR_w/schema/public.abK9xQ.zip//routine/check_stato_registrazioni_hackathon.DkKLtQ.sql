create function check_stato_registrazioni_hackathon() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verifica se la data di inizio è meno di 2 giorni dalla data corrente
    IF NEW.data_inizio <= CURRENT_DATE + INTERVAL '2 days' AND NEW.data_inizio > CURRENT_DATE THEN
        NEW.stato_registrazioni := false;
    -- Se la data di inizio è già passata, impostiamo lo stato su false
    ELSIF NEW.data_inizio <= CURRENT_DATE THEN
        NEW.stato_registrazioni := false;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function check_stato_registrazioni_hackathon() owner to postgres;

