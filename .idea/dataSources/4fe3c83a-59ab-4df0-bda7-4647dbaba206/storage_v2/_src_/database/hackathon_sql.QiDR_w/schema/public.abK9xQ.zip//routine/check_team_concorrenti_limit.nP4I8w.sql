create function check_team_concorrenti_limit() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Contiamo il numero di concorrenti nel team
    DECLARE
        num_concorrenti INT;
    BEGIN
        SELECT COUNT(*)
        INTO num_concorrenti
        FROM utente
        WHERE team_id = NEW.team_id
        AND tipo_utente = 'concorrente';
        
        -- Se il numero di concorrenti è maggiore o uguale a 6, solleva un'eccezione
        IF num_concorrenti >= 6 THEN
            RAISE EXCEPTION 'Un team può avere al massimo 6 concorrenti';
        END IF;
        
        RETURN NEW;
    END;
END;
$$;

alter function check_team_concorrenti_limit() owner to postgres;

