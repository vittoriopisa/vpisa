create function check_giudice_id_valutazione() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verifica che l'utente con il giudice_id abbia tipo_utente = 'giudice'
    IF NOT EXISTS (
        SELECT 1
        FROM utente
        WHERE id = NEW.giudice_id
        AND tipo_utente = 'giudice'
    ) THEN
        RAISE EXCEPTION 'giudice_id deve riferirsi a un utente con tipo_utente = ''giudice''';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_giudice_id_valutazione() owner to postgres;

