create function check_team_id() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Se `tipo_utente` è 'concorrente', `team_id` deve essere non nullo
    IF NEW.tipo_utente = 'concorrente' AND NEW.team_id IS NULL THEN
        RAISE EXCEPTION 'team_id non può essere NULL per gli utenti di tipo "concorrente"';
    -- Se `tipo_utente` non è 'concorrente', `team_id` deve essere NULL
    ELSIF NEW.tipo_utente != 'concorrente' AND NEW.team_id IS NOT NULL THEN
        RAISE EXCEPTION 'team_id deve essere NULL per gli utenti che non sono "concorrente"';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_team_id() owner to postgres;

