create function check_max_concorrenti_in_team() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verifica il numero di concorrenti nel team assegnato
    IF NEW.tipo_utente = 'concorrente' THEN
        -- Conta quanti concorrenti ci sono già nel team
        IF (SELECT COUNT(*) FROM utente WHERE team_id = NEW.team_id AND tipo_utente = 'concorrente') >= 6 THEN
            RAISE EXCEPTION 'Un team non può avere più di 6 concorrenti.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_max_concorrenti_in_team() owner to postgres;

