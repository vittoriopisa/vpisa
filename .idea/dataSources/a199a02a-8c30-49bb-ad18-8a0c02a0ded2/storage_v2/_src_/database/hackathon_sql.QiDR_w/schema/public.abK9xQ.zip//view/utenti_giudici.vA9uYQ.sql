create view utenti_giudici(id) as
SELECT id
FROM utente
WHERE tipo_utente::text = 'giudice'::text;

alter table utenti_giudici
    owner to postgres;

