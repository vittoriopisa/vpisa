create function aggiorna_stato_registrazione() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.data_inizio <= CURRENT_DATE + INTERVAL '2 days' THEN
    NEW.stato_registrazione := FALSE;
  ELSE
    NEW.stato_registrazione := TRUE;
  END IF;
  RETURN NEW;
END;
$$;

alter function aggiorna_stato_registrazione() owner to postgres;

