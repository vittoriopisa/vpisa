create function check_organizzatore_id() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verifica che l'utente con l'organizzatore_id abbia tipo_utente = 'organizzatore'
    IF NOT EXISTS (
        SELECT 1
        FROM utente
        WHERE id = NEW.organizzatore_id
        AND tipo_utente = 'organizzatore'
    ) THEN
        RAISE EXCEPTION 'organizzatore_id deve riferirsi a un utente con tipo_utente = ''organizzatore''';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_organizzatore_id() owner to postgres;

