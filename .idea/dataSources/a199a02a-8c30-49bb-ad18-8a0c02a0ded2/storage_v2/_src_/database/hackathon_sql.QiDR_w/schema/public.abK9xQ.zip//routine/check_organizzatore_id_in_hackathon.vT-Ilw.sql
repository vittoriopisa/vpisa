create function check_organizzatore_id_in_hackathon() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verifica che l'organizzatore_id esista e abbia tipo_utente = 'organizzatore'
    IF NOT EXISTS (
        SELECT 1
        FROM utente
        WHERE id = NEW.organizzatore_id
        AND tipo_utente = 'organizzatore'
    ) AND NEW.organizzatore_id IS NOT NULL THEN
        RAISE EXCEPTION 'organizzatore_id deve riferirsi a un utente con tipo_utente = ''organizzatore''';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_organizzatore_id_in_hackathon() owner to postgres;

