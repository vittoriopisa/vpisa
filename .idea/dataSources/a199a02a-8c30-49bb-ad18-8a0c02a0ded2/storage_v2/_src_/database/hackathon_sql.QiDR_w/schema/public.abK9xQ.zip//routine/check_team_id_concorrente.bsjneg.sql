create function check_team_id_concorrente() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Se l'utente non è di tipo 'concorrente' e il team_id non è nullo, solleva un'eccezione
    IF NEW.tipo_utente <> 'concorrente' AND NEW.team_id IS NOT NULL THEN
        RAISE EXCEPTION 'Il campo team_id può essere non nullo solo per utenti di tipo "concorrente"';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_team_id_concorrente() owner to postgres;

